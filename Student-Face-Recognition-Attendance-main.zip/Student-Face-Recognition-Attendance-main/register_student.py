
import cv2
import json
import shutil
import re
import numpy as np

from pathlib import Path


# ==========================================
# PROJECT PATHS
# ==========================================

BASE_DIR = Path(__file__).resolve().parent

DATASET_DIR = BASE_DIR / "dataset"

STUDENTS_FILE = BASE_DIR / "students.json"

MODEL_DIR = BASE_DIR / "models"

MODEL_FILE = MODEL_DIR / "face_model.yml"

LABELS_FILE = MODEL_DIR / "labels.json"


# ==========================================
# SETTINGS
# ==========================================

MAX_PHOTOS = 10

FACE_MATCH_THRESHOLD = 65

FACE_SIZE = (200, 200)


CASCADE_FILE = (
    cv2.data.haarcascades
    + "haarcascade_frontalface_default.xml"
)


# ==========================================
# LOAD STUDENTS
# ==========================================

def load_students():

    if not STUDENTS_FILE.exists():

        return {}

    try:

        with STUDENTS_FILE.open(
            "r",
            encoding="utf-8"
        ) as file:

            students = json.load(file)

            if isinstance(students, dict):

                return students

            print(
                "Invalid students.json format."
            )

            return {}

    except (json.JSONDecodeError, OSError) as error:

        print(
            "Could not load students.json:",
            error
        )

        return {}


# ==========================================
# SAVE STUDENTS
# ==========================================

def save_students(students):

    STUDENTS_FILE.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    with STUDENTS_FILE.open(
        "w",
        encoding="utf-8"
    ) as file:

        json.dump(
            students,
            file,
            indent=4
        )


# ==========================================
# STUDENT NAME VALIDATION
# ==========================================

def get_student_name():

    while True:

        name = input(
            "Enter student name: "
        ).strip()

        if not name:

            print(
                "Name cannot be empty."
            )

            continue

        # English alphabets and spaces only.
        # Same name with a different register
        # number is allowed.

        if not re.fullmatch(
            r"[A-Za-z ]+",
            name
        ):

            print(
                "INVALID STUDENT NAME!"
            )

            print(
                "Enter alphabets and spaces only."
            )

            print(
                "Numbers and special characters "
                "are not allowed."
            )

            continue

        if not any(
            character.isalpha()
            for character in name
        ):

            print(
                "Name must contain alphabets."
            )

            continue

        return name


# ==========================================
# REGISTER NUMBER VALIDATION
# ==========================================

def get_register_number():

    while True:

        reg_no = input(
            "Enter register number: "
        ).strip()

        if not reg_no:

            print(
                "Register number cannot be empty."
            )

            continue

        # Digits only.

        if not re.fullmatch(
            r"[0-9]+",
            reg_no
        ):

            print(
                "INVALID REGISTER NUMBER!"
            )

            print(
                "Enter numeric digits only."
            )

            continue

        # Reject zero-only register numbers.

        if int(reg_no) == 0:

            print(
                "Register number cannot be zero."
            )

            continue

        return reg_no


# ==========================================
# LOAD FACE RECOGNIZER
# ==========================================

def load_existing_recognizer():

    if not hasattr(cv2, "face"):

        print(
            "OpenCV face module is missing."
        )

        print(
            "Install opencv-contrib-python."
        )

        return None, {}

    if not MODEL_FILE.exists():

        return None, {}

    if not LABELS_FILE.exists():

        return None, {}

    try:

        recognizer = (
            cv2.face.LBPHFaceRecognizer_create()
        )

        recognizer.read(
            str(MODEL_FILE)
        )

        with LABELS_FILE.open(
            "r",
            encoding="utf-8"
        ) as file:

            labels = json.load(file)

        return recognizer, labels

    except Exception as error:

        print(
            "Could not load trained model:",
            error
        )

        return None, {}


# ==========================================
# FACE PREPROCESSING
# ==========================================

def preprocess_face(face):

    face = cv2.resize(
        face,
        FACE_SIZE
    )

    face = cv2.equalizeHist(
        face
    )

    return face


# ==========================================
# FIND STUDENT INFORMATION
# ==========================================

def find_student_by_label(
    label,
    labels,
    students
):

    label_value = labels.get(
        str(label)
    )

    if label_value is None:

        return None

    # Some label files store register
    # number directly as a string.

    if isinstance(
        label_value,
        (str, int)
    ):

        reg_no = str(
            label_value
        )

        student = students.get(
            reg_no
        )

        if student:

            return {
                "name": student.get(
                    "name",
                ),
                "reg_no": reg_no
            }

        return None

    # Some label files store student
    # information as a dictionary.

    if isinstance(
        label_value,
        dict
    ):

        reg_no = str(
            label_value.get(
                "reg_no",
                label_value.get(
                    "register_number",
                )
            )
        )

        student = students.get(
            reg_no
        )

        if student:

            return {
                "name": student.get(
                    "name",
                    label_value.get("name")
                ),
                "reg_no": reg_no
            }

        if label_value.get("name"):

            return {
                "name": label_value.get(
                    "name"
            ),
                "reg_no": reg_no
            }

    return None


# ==========================================
# CHECK DUPLICATE FACE
# ==========================================

def find_existing_face(
    face,
    recognizer,
    labels,
    students
):

    if recognizer is None:

        return None

    try:

        face = preprocess_face(
            face
        )

        label, confidence = (
            recognizer.predict(face)
        )

        print(
            f"Face comparison distance: "
            f"{confidence:.2f}"
        )

        # Lower LBPH distance means
        # a closer face match.

        if confidence <= FACE_MATCH_THRESHOLD:

            student = find_student_by_label(
                label,
                labels,
                students
            )

            if student:

                return student

    except Exception as error:

        print(
            "Face comparison failed:",
            error
        )

    return None


# ==========================================
# MAIN REGISTRATION
# ==========================================

def main():

    print()
    print(
        "STUDENT FACE REGISTRATION"
    )

    print(
        "========================"
    )

    # --------------------------------------
    # GET VALID STUDENT NAME
    # --------------------------------------

    name = get_student_name()

    # --------------------------------------
    # GET VALID REGISTER NUMBER
    # --------------------------------------

    reg_no = get_register_number()

    # --------------------------------------
    # LOAD EXISTING STUDENTS
    # --------------------------------------

    students = load_students()

    # --------------------------------------
    # CHECK DUPLICATE REGISTER NUMBER
    # --------------------------------------

    if reg_no in students:

        print()

        print(
            "REGISTER NUMBER ALREADY REGISTERED!"
        )

        print(
            "Existing student:",
            students[reg_no]["name"],
            "(" + reg_no + ")"
        )

        print(
            "Please enter a different register number."
        )

        return

    # --------------------------------------
    # LOAD FACE DETECTOR
    # --------------------------------------

    detector = cv2.CascadeClassifier(
        CASCADE_FILE
    )

    if detector.empty():

        print(
            "Could not load face detector."
        )

        return

    # --------------------------------------
    # LOAD EXISTING TRAINED MODEL
    # --------------------------------------

    recognizer, labels = (
        load_existing_recognizer()
    )

    if recognizer is None:

        print()

        print(
            "WARNING: Existing trained face "
            "model was not found."
        )

        print(
            "Duplicate face checking is unavailable."
        )

        print(
            "Train the existing students first "
            "using train_model.py."
        )

    # --------------------------------------
    # STUDENT DATASET DIRECTORY
    # --------------------------------------

    student_dir = (
        DATASET_DIR / reg_no
    )

    if student_dir.exists():

        if any(
            student_dir.iterdir()
        ):

            print()

            print(
                "A photo folder already exists "
                "for this register number."
            )

            print(
                "Check the existing folder "
                "before registering."
            )

            return

    student_dir.mkdir(
        parents=True,
        exist_ok=True
    )

    # --------------------------------------
    # OPEN WEBCAM
    # --------------------------------------

    camera = cv2.VideoCapture(
        0,
        cv2.CAP_DSHOW
    )

    if not camera.isOpened():

        print(
            "Cannot open webcam."
        )

        shutil.rmtree(
            student_dir,
            ignore_errors=True
        )

        return

    # --------------------------------------
    # REGISTRATION VARIABLES
    # --------------------------------------

    count = 0

    duplicate_student = None

    cancelled = False

    # --------------------------------------
    # REGISTRATION INSTRUCTIONS
    # --------------------------------------

    print()

    print(
        "Look at the camera."
    )

    print(
        "Press SPACE to capture a photo."
    )

    print(
        f"Exactly {MAX_PHOTOS} photos "
        "are required."
    )

    print(
        "Press Q to cancel."
    )

    print()

    # ======================================
    # CAMERA CAPTURE LOOP
    # ======================================

    try:

        while count < MAX_PHOTOS:

            ok, frame = camera.read()

            if not ok or frame is None:

                print(
                    "Could not read webcam."
                )

                cancelled = True

                break

            # --------------------------------
            # CONVERT TO GRAYSCALE
            # --------------------------------

            gray = cv2.cvtColor(
                frame,
                cv2.COLOR_BGR2GRAY
            )

            # --------------------------------
            # DETECT FACES
            # --------------------------------

            faces = detector.detectMultiScale(
                gray,
                scaleFactor=1.1,
                minNeighbors=5,
                minSize=(80, 80)
            )

            face_box = None

            # --------------------------------
            # SELECT LARGEST FACE
            # --------------------------------

            if len(faces) > 0:

                face_box = max(
                    faces,
                    key=lambda box:
                    box[2] * box[3]
                )

                x, y, w, h = face_box

                cv2.rectangle(
                    frame,
                    (x, y),
                    (x + w, y + h),
                    (0, 255, 0),
                    2
                )

            # --------------------------------
            # DISPLAY PHOTO COUNT
            # --------------------------------

            cv2.putText(
                frame,
                f"Photos: {count}/{MAX_PHOTOS}",
                (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                (0, 255, 0),
                2
            )

            # --------------------------------
            # DISPLAY CAMERA
            # --------------------------------

            cv2.imshow(
                "AIML Student Registration",
                frame
            )

            key = (
                cv2.waitKey(1)
                & 0xFF
            )

            # --------------------------------
            # CANCEL REGISTRATION
            # --------------------------------

            if key == ord("q"):

                cancelled = True

                break

            # --------------------------------
            # CAPTURE PHOTO
            # --------------------------------

            if key == 32:

                if face_box is None:

                    print(
                        "No face detected."
                    )

                    print(
                        "Please try again."
                    )

                    continue

                x, y, w, h = face_box

                # --------------------------------
                # EXTRACT FACE
                # --------------------------------

                face = gray[
                    y:y + h,
                    x:x + w
                ]

                # --------------------------------
                # CHECK DUPLICATE FACE
                # --------------------------------

                duplicate_student = (
                    find_existing_face(
                        face,
                        recognizer,
                        labels,
                        students
                    )
                )

                if duplicate_student:

                    print()

                    print(
                        "ALREADY REGISTERED FACE DETECTED!"
                    )

                    print(
                        "Matched student:",
                        duplicate_student["name"]
                    )

                    print(
                        "Register number:",
                        duplicate_student["reg_no"]
                    )

                    print(
                        "Registration cancelled."
                    )

                    cancelled = True

                    break

                # --------------------------------
                # PREPROCESS FACE
                # --------------------------------

                face = preprocess_face(
                    face
                )

                # --------------------------------
                # SAVE PHOTO
                # --------------------------------

                next_count = count + 1

                image_path = (
                    student_dir
                    / f"face_{next_count:03d}.jpg"
                )

                saved = cv2.imwrite(
                    str(image_path),
                    face
                )

                if saved:

                    count = next_count

                    print(
                        f"Saved photo "
                        f"{count}/{MAX_PHOTOS}"
                    )

                else:

                    print(
                        "Could not save photo."
                    )

    finally:

        # ----------------------------------
        # RELEASE CAMERA
        # ----------------------------------

        camera.release()

        cv2.destroyAllWindows()

    # ======================================
    # DUPLICATE FACE RESULT
    # ======================================

    if duplicate_student is not None:

        shutil.rmtree(
            student_dir,
            ignore_errors=True
        )

        print()

        print(
            "DUPLICATE STUDENT REGISTRATION BLOCKED."
        )

        print(
            "Existing student:",
            duplicate_student["name"]
        )

        print(
            "Existing register number:",
            duplicate_student["reg_no"]
        )

        print(
            "No new student was registered."
        )

        return

    # ======================================
    # SUCCESSFUL REGISTRATION
    # ======================================

    if count == MAX_PHOTOS and not cancelled:

        students[reg_no] = {
            "name": name
        }

        save_students(
            students
        )

        print()

        print(
            "REGISTRATION SUCCESSFUL!"
        )

        print(
            "Student name:",
            name
        )

        print(
            "Register number:",
            reg_no
        )

        print(
            f"Saved exactly {MAX_PHOTOS} photos."
        )

        print()

        print(
            "Next step:"
        )

        print(
            "python train_model.py"
        )

    # ======================================
    # CANCELLED REGISTRATION
    # ======================================

    else:

        shutil.rmtree(
            student_dir,
            ignore_errors=True
        )

        print()

        print(
            f"Registration cancelled "
            f"after {count} photos."
        )

        print(
            "Incomplete photos were removed."
        )

        print(
            "The student was not registered."
        )


# ==========================================
# START PROGRAM
# ==========================================

if __name__ == "__main__":

    main()
